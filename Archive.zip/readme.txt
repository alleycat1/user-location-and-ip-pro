=== User Location and IP ===
Contributors: sunnybundel
Tags: ip address, location ip, track ip location, location by ip address, current ip address, user ip address, user country code, user location, user city, user country, display user ip, user ip shortcode, user country flag
Requires at least: 5.4
Tested up to: 6.0
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

User Location and IP is a free shortcode based Wordpress plugin that displays real-time information about your users, including their IP address, location, country name, flag, and various other details on any Wordpress post page or widget.


== Description ==

"User Location and IP" plugin is one of the best free WordPress plugins that let you know all the information about your visitors in real-time, including their IP address, ISP details, location, operating system, browser, city, and many other details, all of which can be displayed via shortcodes on your website posts, pages, and widget.

In order to use this plugin, you just need to copy one of the appropriate shortcodes from the list below. You can paste it into the location where you want the details to appear. This can be in the sidebar, the header, the footer, or even in the middle of the content.

"User Location and IP" plugin uses the <a href="http://ip-api.com" rel="friend" title="IP-API">IP-API</a> website to fetch users details based on their IP address.

Here's the list of various shortcodes provided by the "User Location and IP" plugin:

<code>[useriploc type="ip"]</code>
<code>[useriploc type="continent"]</code>
<code>[useriploc type="country"]</code>
<code>[useriploc type="countrycode"]</code>
<code>[useriploc type="region"]</code>
<code>[useriploc type="regionname"]</code>
<code>[useriploc type="city"]</code>
<code>[useriploc type="lat"]</code>
<code>[useriploc type="lon"]</code>
<code>[useriploc type="timezone"]</code>
<code>[useriploc type="currency"]</code>
<code>[useriploc type="isp"]</code>
<code>[useriploc type="browser"]</code>
<code>[useriploc type="os"]</code>
<code>[useriploc type="flag" height="auto" width="50px"]</code>

As for the Flag shortcode, height or width attributes are optional. The default values for height and weight are auto and 50px respectively. Depending on your preference, you can pass one or both of these values to alter the flag's size.

= Features of User IP and Location =

* Setup is quick and easy.
* Installation is minimal and does not increase the load on the website.
* "User Location and IP" provides live and accurate data that is up-to-date.
* Allows you to display user IP address and location, operating system, browser details, etc anywhere on your website using shortcodes.
* Support for flags and currency shortcodes.

If you are looking for a plugin that can display visitors' real-time information anywhere on your blog, then User Location and IP can help you. The plugin is free and doesn't require any registration.

= Credits =

I am pleased to announce the release of this plugin which was created by <a href="https://sunnybundel.com/" rel="friend" title="Sunny Bundel">Sunny Bundel</a> with the help of the team at <a href="https://mytechtalky.com/" rel="friend" title="MyTechTalky"> MyTechTalky</a>.

There are also tutorials available on MyTechTalky about WordPress, including:

* <a href="https://mytechtalky.com/start-a-blog/" rel="friend" title="How to Start a Blog Using WordPress"> How to Start a Blog Using WordPress </a>

…and many more <a href="https://mytechtalky.com/wordpress/" rel="friend" title="WordPress Tutorial">WordPress tutorials</a>.


== Installation ==

### Directly from the WordPress repository (recommended)
* Navigate to _Dashboard > Plugins > Add New_.
* Enter _User Location and IP_ in the search box.
* Click on the _Install_ button.
* Finally, click on the _Activate_ button.

### Manual Installation
* Download the "User location and IP" plugin from the WordPress Repository as a `.zip` file.
* Navigate to _Dashboard > Plugins > Add New_.
* Click on the Upload Plugin button.
* Now choose the .zip file which you downloaded and click on _Install Now_.
* Finally, click on the _Activate_ button.

== Screenshots ==

1. An example of shortcodes in "Add New Post"
2. Screenshot of "Public Post" page with IP address and other information about the user.

== Frequently Asked Questions ==

= Can I use User Location and IP to Show User IP? =

Yes, you can use the <code>[useriploc type="ip"]</code> shortcode to show the IP address of the visitor.

= Can I use User Location and IP to Show User Location? =

You can use the shortcodes provided with "User Location and IP" plugin to show a user's location, including country, region, country code, city, latitude, longitude, and other useful information.

= Are flags supported by this plugin? =

Yes, flag shortcodes are supported by this plugin. You can display the flag of a visitor's country using the [useriploc type="flag" height="auto" width="50px"] shortcode. Height and width are optional, and the default values are auto for height and 50px for width. It is possible to pass any or both of these values to change the flag's size.

== Changelog ==

* initial release

== Upgrade Notice ==
 
This is a major update to the plugin. For better performance, make sure to update.