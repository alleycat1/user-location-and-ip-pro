<?php
# Silence is golden.
?>