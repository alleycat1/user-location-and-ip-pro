<?php
/**
 * Loading the admin file
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

require_once USER_LOCATION_AND_IP_ADMIN_PATH . 'user-ip-menu.php';
require_once USER_LOCATION_AND_IP_ADMIN_PATH . 'user-ip-menu-options.php';

